// Ladder.java

class Ladder extends Connection
{
  Ladder(int ladderStart, int ladderEnd)
  {
    super(ladderStart, ladderEnd);
  }

}
