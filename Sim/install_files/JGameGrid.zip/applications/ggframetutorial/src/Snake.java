// Snake.java

class Snake extends Connection
{
   Snake(int snakeStart, int snakeEnd)
   {
     super(snakeStart, snakeEnd);
   }
}
