// Select.java

import ch.aplu.jgamegrid.*;

public class Select extends Actor
{
  public Select()
  {
    super("sprites/select.gif");
  }
}
