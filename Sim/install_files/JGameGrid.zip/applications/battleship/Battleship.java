// Battleship.java

public class Battleship extends Ship
{
  public Battleship()
  {
    super("sprites/battleship.gif", 4);
  }
}
