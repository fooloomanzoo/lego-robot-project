// Destroyer.java


public class Destroyer extends Ship
{
  public Destroyer()
  {
    super("sprites/destroyer.gif", 4);
  }
}
