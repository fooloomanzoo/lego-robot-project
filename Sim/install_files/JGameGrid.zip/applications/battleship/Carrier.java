// Carrier.java


public class Carrier extends Ship
{
  public Carrier()
  {
    super("sprites/carrier.gif", 5);
  }
}
