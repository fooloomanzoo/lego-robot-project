// PatrolBoat.java


public class PatrolBoat extends Ship
{
  public PatrolBoat()
  {
    super("sprites/patrol.gif", 2);
  }
}
