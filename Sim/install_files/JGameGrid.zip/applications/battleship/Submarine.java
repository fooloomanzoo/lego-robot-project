// Submarine.java


public class Submarine extends Ship
{
  public Submarine()
  {
    super("sprites/submarine.gif", 3);
  }
}
