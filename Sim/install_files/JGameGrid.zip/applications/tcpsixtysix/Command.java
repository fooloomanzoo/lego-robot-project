// Command.java

public interface Command
{
  int REPORT_NAMES = 0;
  int DISCONNECT = 1;
  int GAME_STARTING = 2;
  int MY_TURN = 3;
  int OTHER_TURN = 4;
  int READY_FOR_FAN = 5;
  int FAN_DATA = 6;
  int FAN_SELECTED_CARD = 7;
}
 
