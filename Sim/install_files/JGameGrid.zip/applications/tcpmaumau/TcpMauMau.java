// TcpMau.java

public class TcpMauMau
{
  protected static final String version = "1.21";
  protected static final boolean debug = false;

  public static void main(String[] args)
  {
    new MauMauAgent();
  }
}
