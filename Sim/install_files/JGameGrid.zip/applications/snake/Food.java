// Food.java

import ch.aplu.jgamegrid.*;

class Food extends Actor
{
  public Food()
  {
    super("sprites/sMouse.gif");
  }
}

