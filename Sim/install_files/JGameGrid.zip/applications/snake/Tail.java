// Tail.java

import ch.aplu.jgamegrid.*;

class Tail extends Actor
{
  public Tail()
  {
    super("sprites/snakeTail.gif");
  }
}
