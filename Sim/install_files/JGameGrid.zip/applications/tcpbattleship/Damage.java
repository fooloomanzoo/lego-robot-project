// Damage.java

public enum Damage
{
  HIT, MISS, SUNK, ALLSUNK
}


