# TuEx1.py



from javax.swing import UIManager
UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName())

print 2