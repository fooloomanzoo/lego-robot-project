# TuEx1a.py

from gturtle import *

makeTurtle()

repeat 4:
   fd(100)
   rt(90)


