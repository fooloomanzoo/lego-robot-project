# SimEx03.py
# TurtleRobot
from simrobot import *                         

robot = TurtleRobot()
for i in range(4):
  robot.forward(100)
  robot.left(90)
robot.exit();

