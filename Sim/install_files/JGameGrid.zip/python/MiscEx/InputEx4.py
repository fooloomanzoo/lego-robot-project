# InputEx4.py

n = 0
isRunning = True
while isRunning:
   print n
   n += 1
   isRunning = askYesNo("Continue?")    
print "All done"  


