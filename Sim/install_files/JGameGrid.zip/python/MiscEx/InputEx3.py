# InputEx3.py

name = ""
while name != None:
   name = inputString("Your name?", False)
   if name != None:
      print "Your name is " + name
print "All done"        
