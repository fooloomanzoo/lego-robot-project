# InputEx2.py

while True:
   x = inputFloat("What is your age?")
   print "got : " + str(x)
   print str(type(x))        
