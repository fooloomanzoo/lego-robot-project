# InputEx1.py

while True:
   x = input("Enter a string/int/float")
   print "got : " + str(x)
   print str(type(x))
